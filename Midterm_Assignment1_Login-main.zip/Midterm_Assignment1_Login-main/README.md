# Midterm_Assignment1_Login

# Instructions (how to run the program locally) :
     1. Open GitHub or GitHub Desktop.
     2. Clone this repository, (Midterm_Assignment1_Login). 
        Note: Database are not included on this version (will update soon).
     3. Open the file on either VS Code or Visual Studio 2022.
     4. Happy Programming :)
